module CounterFactory {
}